# A7 Board

Turns your customer reviews into the "IF YOU / YOU NEED" whiteboard ad. A supplement brand put this same board up against a chalkboard version of the same ad, and the chalkboard was shut off in 18 days. The skill reads your reviews, finds the six most common reasons people bought from you (each one backed by real reviews, quoted word for word), writes the full 60-second ad, draws the hand-drawn board, animates it with Wan 3.0, and voices and captions it into a ready 9:16 clip.

## What's in here

```
a7-board/
├── README.md              (this file)
├── a7-board.zip           (the upload for claude.ai)
└── skills/a7-board/       (the skill folder for Claude Code)
    ├── SKILL.md           (the workflow)
    ├── references/        (reading reviews, the six lines, the script, the board)
    ├── scripts/           (check_lines.py checks every quote; assemble.py cuts the clip)
    └── examples/          (a finished board for a metal-roof company, from 421 reviews)
```

## What you need
- **Claude Code on a Mac**, with `ffmpeg` (`brew install ffmpeg`) and `uv`. The final cut runs on your computer.
- **Higgsfield, connected to Claude.** About 50 credits a board: the drawing is 0.25 a try, the voice about 1.5, and Wan about 47 for a 27-second board at 720p. Claude quotes the credits and waits for your "go" before anything costs more than a drawing.
- **Your reviews: 200 or more if you have them.** A file, a paste, or a link. Google hides reviews from logged-out browsers, so copy them from your Business Profile, or use Claude in Chrome while signed in. Not many reviews? It can read your competitors' reviews too: same buyers.

## Install

**Claude Code:** copy the skill folder into your skills directory, then start a new session.

    cp -R "skills/a7-board" ~/.claude/skills/

**claude.ai:** first turn on "Code execution and file creation" in Settings → Capabilities. Then Customize → Skills → + → Create skill → Upload a skill → pick `a7-board.zip`. Everything up to the board video works there; the final cut needs Claude Code.

## Use it

| Say | You get |
|---|---|
| "Make a board for [business]" | The whole run: reviews → six lines → script → board → clip |
| "Read my reviews" | Every reason people bought, counted, with their words |
| "Write the six lines" | The six rows, each checked against the reviews it quotes |
| "Build the board" | The drawing, then (after your go) the Wan video |
| "Voice the board" | Six voiced lines and the captioned 9:16 clip |

## The rules it follows
1. **Nothing invented.** Every line has at least two reviews behind it, every quote is checked word for word by a script, and any claim or offer you haven't confirmed stays a question.
2. **Your customers' words,** not marketing words.
3. **Inside Meta's rules.** No line names a health condition, money trouble or any other personal attribute; it names the sign instead.
4. **Checked before it's spent.** Every word on the board is read before Wan runs.
