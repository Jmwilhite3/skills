# Buyers: a metal-roof company

**Sample:** 421 Trustpilot reviews of a US metal-roof company, read 24 Oct 2026: the 200 newest, plus the newest 4-star and 3-star (Trustpilot shows 10 pages of 20 when logged out). Stars: 169 five, 196 four, 42 three, 3 two, 11 one. Dates 22 Dec 2022 to 19 Oct 2026. The full reviews aren't shipped with the skill (they're 421 people's words); the quotes below are the receipts.

**What the reviews talk about:** mostly the install. About 1 in 8 says anything about what was going on before. 48 say the roof went on in one day, 40 the price, 15 sales pressure, 12 compliments from neighbours.

## Every buyer found, most reviews first
| Buyer | Reviews | Their words |
|---|---|---|
| Their roof leaks when it rains | 6 | "We developed a leak during alot of rain storms"; "having issues with leaking in our sunroom and in the garage"; "an active leak over electrical boxes"; "no more leaks!" |
| They never want to deal with a roof again | 5 | "a beautiful roof that I will never have to worry about again"; "the last roof that I will have to worry about"; "The 50 year warranty on the metal roof provides us with peace of mind" |
| The last roofer got it wrong | 3 | "errors that two other roofers did that started to cause water damage"; "our previous roofer's shortcomings" |
| The old roof is worn out | 3 | "a roof that had no life in it"; "our 20+ year old roof" |
| A storm is coming | 3 | "a storm with high winds and heavy rain is moving in"; "we will get hurricane effects" |
| Trouble with home insurance | 3 | "the issues that we were having with our home insurance"; "make our house insurance go down" |
| The house runs hot | 2 | "The inside is definitely Cooler with lower temperature settings than before"; "savings in our electricity" |
| Getting ready to sell | 2 | "I was ready to sell my house"; "When we sell the house it will add to the resale value" |
| Tired of climbing the ladder to clean gutters | 2 | "Won't have climb on the ladder anymore" (gutter guards, not the roof: off this board) |
| Wet basement | 9 | waterproofing jobs: a different product, so a different board |

## The six, and why these
Ordered as the rules say: the most common and most visible first, the widest last.
1. **Your roof leaks when it rains** (6): the most reviews, and you can see it on the ceiling.
2. **The last roofer got it wrong** (3)
3. **Roof has no life left in it** (3)
4. **There's a storm on the way** (3): a different person from row 1, someone with no leak yet.
5. **Having issues with your home insurance** (3): about the house's cover, not the viewer's money, so it stays inside Meta's personal-attributes rule.
6. **You never want to worry again** (5): almost any homeowner can claim it, so it closes the board.

Runners-up: the hot house and selling (2 each). Swap one in if the owner knows it's common.

## Objections the script has to respect
- **Price (40 reviews):** "a little more than their competitors", "nearly 50% higher than other roofing companies in the area". The script doesn't claim it's cheap; it says what the money buys (the warranty, the one-day job).
- **Sales pressure (15):** the script makes no "no pressure" claim.
- **Slow callbacks after the job (9):** no claim about service after the sale.

## Receipts (from `check_lines.py`)
| # | Line | Reviews | Their words |
|---|---|---|---|
| 1 | Your roof leaks when it rains | 6 | "We developed a leak during alot of rain storms" (r001); "We we're having issues with leaking in our sunroom and in the garage" (r002); "The inspectors found an active leak over electrical boxes" (r003); "some rather serious leak problems" (r004); "no more leaks!" (r005); "lots of wind and heavy rain. Roof is withstanding the elements. No more leaks." (r006) |
| 2 | The last roofer got it wrong | 3 | "corrected errors that two other roofers did that started to cause water damage" (r007); "some structural repairs to correct our previous roofer's shortcomings" (r008); "we needed to solve these old construction deficiencies" (r009) |
| 3 | Roof has no life left in it | 3 | "They tore off a roof that had no life in it" (r010); "our 20+ year old roof" (r008); "to replace our old roof" (r011) |
| 4 | There's a storm on the way | 3 | "a storm with high winds and heavy rain is moving in" (r007); "Especially since we will get hurricane effects" (r012); "it just weathered the atmospheric river of rain and wind with no issues" (r013) |
| 5 | Having issues with your home insurance | 3 | "the issues that we were having with our home insurance" (r014); "It's also going to make our house insurance go down" (r015); "We've already seen savings in our electricity and homeowners insurance" (r016) |
| 6 | You never want to worry again | 5 | "beautiful roof that I will never have to worry about again" (r017); "This will be the last roof that I will have to worry about" (r018); "We will never have to worry about the roof again" (r015); "the roof has a 50 year warranty which was well worth it to me" (r019); "The 50 year warranty on the metal roof provides us with peace of mind" (r011) |
