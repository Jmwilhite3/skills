# Board ad: a metal-roof company

About 60 s, 9:16. The board runs 25.4 s (`board-ad.mp4`): each row lasts as long as its line. Spoken as the business ("That's why we…"). Counts are from 421 Trustpilot reviews read on 24 Oct 2026 (not shipped with the skill).

| Time | Picture | Voice | On screen |
|---|---|---|---|
| 0:00 | `board.mp4`, the pointer on row 1 | If your roof leaks when it rains, you need a metal roof. | the spoken line |
| 0:04 | pointer on row 2 | If the last roofer got it wrong, you need a metal roof. | the spoken line |
| 0:08 | row 3 | If your roof has no life left in it, you need a metal roof. | the spoken line |
| 0:13 | row 4 | If there's a storm on the way, you need a metal roof. | the spoken line |
| 0:17 | row 5 | If you're having issues with your home insurance, you need a metal roof. | the spoken line |
| 0:21 | row 6 | If you never want to worry again, you need a metal roof. | the spoken line |
| 0:25 | **The turn.** The pointer taps row 2 again | Most people go with the cheapest quote. But the cheap roof is how you end up on this list. | |
| 0:30 | **The answer.** A finished metal roof, then the crew at work | That's why we put on metal roofs. Most go on in a single day, and they come with a 50-year warranty. | Done in a day · 50-year warranty |
| 0:36 | **How it works.** Close-up of the metal shingles locking together; the ice and water shield going down; rain on the finished roof | The metal shingles lock together over an ice and water shield, so rain just slides off instead of settling into the cracks of the asphalt. | |
| 0:46 | **What changes,** one row at a time | No more leaks. Storms roll through with no issues. And it's the last roof you'll have to worry about. | |
| 0:51 | **The offer.** The house from the street | [CONFIRM: the current offer]. Tap the link below to book your free inspection. | [CONFIRM: offer] · Book a free inspection |

## Where each line comes from
- **The turn:** reviewers who'd been burned by the last job: "errors that two other roofers did", "our previous roofer's shortcomings", and "I could have had someone come in and put on a cheap roof" (r020).
- **"In a single day":** 48 of the 421 reviews say the roof went on in one day (read one by one; a keyword pass found 56, eight of them false hits like "added one day" and a same-day sales price).
- **"50-year warranty":** five reviews mention it on the metal roof; others mention 30 years (shingle roofs).
- **"Lock together", "ice and water shield", "rain just slides off… cracks of the asphalt":** reviews r011 ("The way the metal roof interlocked"), r004 ("the water and ice shield and underlayment") and r021 ("Rain just slides off of it rather than settling into the cracks of the asphalt").
- **"What changes"** answers rows 1, 4 and 6 in order, in reviewers' words: "No more leaks", "weathered the atmospheric river of rain and wind with no issues", "the last roof that I will have to worry about".

## Left out on purpose
- Nothing about price being low: 40 reviews say it costs more than other roofers.
- No "no pressure" claim: 15 reviews mention sales pressure.
- No claim that insurance goes down: two reviewers say theirs did, but it depends on the insurer.
- No cleanup claim: most reviews praise it, but about 10 found nails left in the yard ("I probably picked up over 200").

## [CONFIRM] before it runs
1. What's the current offer, and when does it end?
2. Is the inspection free, and is that what the link books?
3. The metal roof warranty: is it 50 years, and what does it cover (materials, labour, transferable)?
4. "Most go on in a single day": true across your markets, or only for a typical single-storey home?
5. The footage for 0:24–1:00: a finished metal roof, the crew at work, a close-up of the shingles locking, the ice and water shield, rain on a finished roof.
