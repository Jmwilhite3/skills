# The six lines: `lines.json`

## What a line is
Each row of the board has two parts:
- **`board`**: what's handwritten in the IF YOU box, 7 words or fewer ("Your roof leaks every time it rains").
- **`spoken`**: what the voice says, starting with "If" ("If your roof leaks every time it rains"). The voice then says the answer: "…you need a metal roof."

True Nutra's six, for comparison (board text): socks leave marks around your ankles · the veins on your legs keep looking darker · your clothes feel tighter than usual · your face looks puffy every morning · your legs look dimpled and uneven · you feel deeply fatigued. Every one is a sign you can check on yourself, none names a condition, and the answer is the same six times.

## The rules
1. **Six different buyers.** Read the lines in pairs: if the same person would nod at both, merge them and promote the next buyer from `buyers.md`.
2. **Two reviews or more behind every line,** three or more where you can. A line backed by one review is a guess.
3. **Their words.** Take the reviewer's phrase and trim it; don't rewrite it into marketing. "A roof that had no life in it" beats "an aging roof". When the evidence is a contrast ("no more leaks"), turn it back into the before in the plainest words the reviews use ("your roof leaks").
4. **Checkable in a second.** A sign, a moment or a situation the viewer can answer yes or no to right now. Not a benefit ("you want peace of mind"), not a feeling we hand them. A want counts only when buyers say it about themselves, in their words ("you never want to worry about your roof again").
5. **No personal attributes.** Meta bans ads that assert or imply health conditions, vulnerable financial status, age, religion and the rest of its list, and "you" language makes that easy to break. Name the sign, not the condition: "your face looks puffy every morning", not "you have lymphedema"; "your insurance company wants a new roof", not "you can't afford your premiums".
6. **One answer, word for word, on every row.** It's the product or the booking, not a benefit, and it's short enough to hand-write under a small drawing (1–3 words: "Metal Roof", "Lymphatic Complex", "Free Inspection").
7. **Order.** Row 1 is the most common buyer with the most visible sign: it's the hook. End on the widest row, the one almost anyone could claim (True Nutra ends on "you feel deeply fatigued").
8. **Every row gets an icon:** one simple object or scene a pen could sketch in a small box (a drip into a bucket, a storm cloud, a calendar page). The answer gets one icon too, the same on every row.

## The file

    {
      "business": "A metal-roof company",
      "answer": "Metal Roof",
      "answer_spoken": "a metal roof",
      "answer_icon": "a small house with a ribbed metal roof",
      "row_seconds": 4.5,
      "lines": [
        {
          "board": "Your roof leaks every time it rains",
          "spoken": "If your roof leaks every time it rains",
          "icon": "water dripping from a ceiling into a bucket",
          "receipts": [
            {"id": "r001", "quote": "We developed a leak during alot of rain storms"},
            {"id": "r002", "quote": "having issues with leaking in our sunroom and in the garage"}
          ]
        }
      ]
    }

`arrivals`, `rows_y` and `camera` are added in steps 7–8, once the Wan clip exists (`references/board.md`). `row_seconds` is how long the pointer rests on each row, and so how long each spoken line may run. Use 4.5: it fits about 13 spoken words ("If you're having issues with your home insurance, you need a metal roof" ran 4.1 s). True Nutra's rows run about 4 s, but at 4 s three of the roofer test's six lines ran into the next one. The board video is rows × `row_seconds` long (27 s for six).

## The check

    python3 scripts/check_lines.py board/<slug>

It fails on any of these, and lists every failure at once:
- not exactly six lines (pass `--rows N` for a shorter board, and say why in `buyers.md`)
- a line with fewer than two receipts from different reviews
- a receipt id that isn't in `reviews.jsonl`, or a quote that isn't in that review word for word (case, spacing and curly quotes are ignored; nothing else is)
- a board line over 7 words, a spoken line that doesn't start with "If", or an empty answer

It prints the receipts table for `buyers.md`. The rules it can't check (different buyers, checkable, no personal attributes, order) are yours: read the six lines out loud before moving on.
