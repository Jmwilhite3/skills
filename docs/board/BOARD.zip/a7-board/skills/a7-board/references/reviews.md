# Reviews: getting them, and reading them for the before

## Getting them: `reviews.jsonl`
One review per line, every field filled where the source has it:

    {"id": "tp-r001", "source": "trustpilot", "stars": 5, "date": "2026-09-02", "text": "…"}

Ids must be stable: the receipts in `lines.json` cite them, and `check_lines.py` looks quotes up by id. Use the platform's own id when there is one; otherwise number them (`r001`, `r002`…) in the order received. Keep the text exactly as written, typos included. Put the title in front of the text when the platform has one ("Title. Text").

**Aim for 200 or more reviews, or every review they have.** Most reviews don't say why the person bought, so it takes a few hundred to find six reasons with two or more reviews each.

| Source | How |
|---|---|
| A file (CSV, JSON, TXT, PDF, screenshots) | Convert it. Read screenshots as images and transcribe them word for word. |
| A paste | Split into reviews, number them. |
| Trustpilot | Logged out, a browser shows 10 pages of 20. Each page's `<script id="__NEXT_DATA__">` holds `props.pageProps.reviews` (id, rating, dates, title, text). Fetch `?page=N&languages=en` from inside an open Trustpilot tab; a bare `curl` gets 403. Add `&stars=4` and `&stars=3` for 400 more: those reviews say more about what went wrong before. |
| Google | Logged out, Google Maps shows a "limited view" with no reviews. Either the owner copies them out of their Business Profile, or you read them in a browser that's signed in to Google (Claude in Chrome), scrolling the Reviews tab. |
| Amazon, Etsy, Shopify review apps, G2, Capterra | Read the public review pages in a browser; record the platform's review id. |

**When their own reviews are too thin** (fewer than about 20 that say why they bought, or a new business), add more in this order, and mark the source on every record:
1. Their other platforms and older reviews.
2. **Their competitors' reviews.** The same buyers write them, and a competitor's 1–3 star reviews often say exactly what the buyer was trying to fix.
3. The owner's own words from buyers: sales-call notes, DMs, intake forms, the questions people ask before they book.

## Reading them: `buyers.md`
Read every review and ask one question: **does it say what was going on before they bought?**

- **Said outright:** "We developed a leak during alot of rain storms." "I didn't know how to fix my roof, I was ready to sell my house."
- **Said as a contrast,** an after that names the before: "No more leaks." "Won't have climb on the ladder anymore." "The inside is definitely cooler with lower temperature settings than before."
- **Not a before:** praise for the crew, the speed, the cleanup, the salesman. Those are proof for the script (step 5), not lines. Expect most reviews to be this. In a metal-roof company's 421 newest Trustpilot reviews, about one in eight says anything about the before.

**Big sets:** a keyword pass (leak, old, storm, insurance, before, again, worry…) is a fine way to find candidates, but judge every candidate by reading it. Keywords miss and mis-hit: in the roofer test, "same day" matched a review of a five-hour sales pitch, not a one-day install.

**Group the befores into buyers.** One buyer is one situation a person would recognise themselves in.
- Different words, same situation: one buyer. "A leak during rain storms", "an active leak over the electrical boxes" and "no more leaks" are one buyer.
- Same word, different situations: different buyers. A leaking roof and a wet basement are two.
- A want counts when buyers say it about themselves in the same words: "a roof I will never have to worry about again", "the last roof that I will have to worry about".

Write `buyers.md` as one table, most reviews first, every buyer you found (not just the top six):

| Buyer | Reviews | Their words (verbatim, with ids) |
|---|---|---|
| Their roof leaks when it rains | 7 | "We developed a leak during alot of rain storms" (tp-…ea04b3); "having issues with leaking in our sunroom and in the garage" (tp-…a51c25); "no more leaks!" (tp-…b78cc9) |

Then, under it, the objections the reviews raise (price, pressure, delays) with counts. The script answers the common ones with facts and never claims the opposite of what reviewers say.
