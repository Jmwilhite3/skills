# The board: draw it, animate it, voice it, cut it

## 1. Draw it: `board.png`
`generate_image`, model `gpt_image_2_5`, `aspect_ratio: "9:16"`, `count: 2` (0.25 credits each in Oct 2026). Fill the template from `lines.json`; change nothing else on the first try.

    A vertical photo, shot from directly above, of a sheet of cream paper clipped to a light brown wooden
    clipboard, lying on a dark navy blanket. The sheet is a hand-drawn chart in black ink pen, like a neat
    doodle notebook page.

    At the top, two hand-lettered headers in bold black marker capitals: "IF YOU" over the left column and
    "YOU NEED" over the right column, with a dashed vertical line between the two columns.

    Below the headers are exactly six rows, evenly spaced, filling the page. Each row has, on the left, a
    wide rounded box containing a small simple black ink sketch and a short phrase in neat handwriting; then
    a hand-drawn arrow pointing right; then, on the right, a smaller rounded box containing a sketch of
    {answer_icon} above the handwritten words "{answer}".

    Row 1 sketch: {icon 1}. Handwriting: "{board 1}"
    … rows 2–6 the same way …

    The handwriting is neat, large and legible, black ink, spelled exactly as written above, each phrase on
    two or three short lines inside its box. The only words on the page are the two headers, the six
    phrases and "{answer}" six times. Even, soft daylight, slight paper texture, realistic photo, the whole
    clipboard in frame.

**Check before anything else costs money.** Download both. Crop the IF YOU column and read it at 2× (`ffmpeg -i board.png -vf "crop=380:820:60:250,scale=760:-1" check.png`), then the YOU NEED column. One wrong or missing letter means redraw. A label the model adds to a sketch on its own (the roofer test's board wrote "HOME INSURANCE" on the insurance form) is fine if it's spelled right and says what the row says. Pick the board with the clearer sketches and keep the other in `tries/`. Note the chosen board's **job id**: Wan starts from it.

## 2. The gate
Show the owner the six lines with their receipts (`buyers.md`), the board, and the script's `[CONFIRM]` list. Quote steps 3–4 with `get_cost: true` and wait for "go". Redrawing the board is cheap; re-running Wan is not.

## 3. Animate it: `board.mp4`
`generate_video`, model `wan3_0`:

    {"model": "wan3_0", "aspect_ratio": "9:16", "resolution": "720p", "generate_audio": false,
     "duration": <rows × row_seconds, rounded up>,
     "medias": [{"role": "start_image", "value": "<the board's job id>"}],
     "prompt": "<below>"}

    Static camera looking straight down at the clipboard; the camera never moves or zooms. A woman's hand
    holding a thin black pointer comes in from the right edge and rests the pointer tip on the first row.
    Every {row_seconds} seconds the pointer moves down to the next row, in order from the top row to the
    sixth row at the bottom, pausing on each row and tapping it gently once. The paper, the drawings, the
    headers and every handwritten word stay exactly the same, sharp and unchanged for the whole video;
    nothing is written, erased or added. Soft daylight, realistic.

Wan 3.0 costs 1.75 credits a second at 720p (27 s = 47.25) and 1 a second at 480p, where small handwriting goes soft.

**Check the words.** Crop a late frame (`-ss 20`) the same way as the board and read it at 2×. Every word must still match the board. If any word changed, re-run Wan; the cut can't fix text.

**Measure when the pointer reaches each row.** Wan doesn't keep time. In the roofer test the hand only came in at 3.4 s, and the rows took 2.7 to 5.5 s each instead of 4.5. So look, then write what you saw into `lines.json`:
1. One frame every half second, tiled, to find roughly where each row starts:

       ffmpeg -i board.mp4 -vf "fps=2,scale=150:-1,tile=9x6" -frames:v 1 map.png

   Frame *i* in the tile is at *i* × 0.5 s, left to right, top to bottom.
2. Frames every quarter second around each change, to pin it down.
3. Add `"arrivals"`: for row 1, the time the hand starts coming in; for rows 2–6, the time the pointer tip reaches the row. The roofer test's were `[3.4, 6.4, 9.1, 14.6, 17.9, 22.3]`.

`assemble.py` then retimes each row's stretch of the clip to fit its line. A stretch it would have to slow below 0.5× or speed past 2× is refused; then re-run Wan.

## 4. Voice it: `voice/take.mp3`, then `voice/01.wav` … `voice/06.wav`
**One take, all six lines.** The same "you need…" six times is the format (True Nutra's voice says "you need a lymphatic complex" six times), but six separate generations each restart the same intonation, and the repeats sound forced. Jimmy heard it on the first test. One continuous read flows from row to row.

`generate_audio`, model `elevenlabs_v4_turbo`, one dialogue turn holding all six lines, each ending in a full stop (`list_voices` for ids; the roofer test used Ainsley, `731b4ffe-e95e-59f4-8c00-81608936091f`):

    {"model": "elevenlabs_v4_turbo", "prompt": "board take",
     "dialogue": [{"text": "<spoken 1>, you need <answer_spoken>. <spoken 2>, you need <answer_spoken>. …",
                   "voice_type": "preset", "voice_id": "<id>"}]}

About 1.3 credits. Save it as `voice/take.mp3`, then split it at its pauses:

    python3 scripts/split_take.py board/<slug>

It cuts at the pause nearest where each line should end (a comma pause can run as long as a full stop, and a breath can split one pause in two), and prints each line's span. Check the six lines are whole before cutting: `hyperframes transcribe voice/03.wav` or listen. The owner can record their own read instead, in one take, saved as `voice/take.mp3`.

## 5. Cut it: `board-ad.mp4`
**The camera move happens here, not in Wan.** True Nutra's board doesn't sit still: it holds wide for two rows, then cuts in close on the IF YOU column as row 3 starts and tilts down with the pointer to row 6. Wan's shot stays locked off (its prompt says so) because the cut can only follow the pointer on a steady shot. The move needs `rows_y` in `lines.json`: the height of row 1's centre and row 6's centre, as fractions of the frame (the roofer board: `[0.25, 0.84]`; measure the box edges on `board.png`). Set `"camera": "punch"` too. `tilt` (a gentle push the whole way) and `still` exist for comparing; `punch` is the default.
Dry run first, on the still board, for free:

    uv run --with pillow python3 scripts/assemble.py board/<slug> --video board.png --out dry-run.mp4

Then the real one:

    uv run --with pillow python3 scripts/assemble.py board/<slug>

With `arrivals`, each row lasts 0.3 s + its line + 0.15 s, and the clip is retimed so the pointer lands on the row just before its line starts (the dry run, on a still, uses `row_seconds` instead). The audio is normalised to -14 LUFS. Captions are the "If…" half, then the "you need…" half, white with a black outline at 70% of the height, like the original, never more than two lines.

**Check the cut:** one frame a second into each line. The pointer has to be on the row being read, all six times, and the close-up has to arrive as row 3's line starts. The roofer test's cut was 24.5 s.
