# The script: `script.md`

The full ad runs about 60 seconds. Its shape is True Nutra's whiteboard ad, timed from the ad itself:

| Time | Beat | True Nutra said | Where yours comes from |
|---|---|---|---|
| 0:00–0:24 | **The board.** Six rows, about 4 s each | "If your socks leave marks around your ankles, you need a lymphatic complex." ×6 | `lines.json` |
| 0:24–0:29 | **The turn.** What people blame, then the real cause | "Most people think it's just aging, but in reality, it's stagnant lymph." | What reviewers say they tried or blamed first, plus the owner's explanation |
| 0:29–0:36 | **The answer,** named, with three quick proofs | "The one I recommend is True Nutra Lymphatic Complex. Six ingredients, lab tested for purity, and just two capsules." | The owner's facts, or a count from the reviews |
| 0:36–0:46 | **How it works,** in plain words | "Burdock root, dandelion root, kelp… They clear lymphatic buildup, restore fluid balance…" | The owner's own explanation |
| 0:46–0:51 | **What changes.** Answer the rows, in the same order | "It brings down swelling, lightens heavy legs, clears puffiness, and restores your energy." | The reviews' afters, in their words ("no more leaks") |
| 0:51–1:00 | **The offer, the risk reversal, the CTA** | "Right now it's buy one, get one free. So don't wait. If you don't feel a difference in 90 days, you get your money back. Tap the link below…" | The owner only |

Two things to copy from it:
- **"What changes" closes the rows.** Each benefit answers a row from the board, in order, so the viewer who found themselves on row 3 hears their row solved.
- **The turn gives the viewer a reason it hasn't worked yet** ("most people think it's just aging"). Use the thing reviewers say they tried first: the patch, the cheap fix, the last company.

## Rules
- **Every claim has a source:** the reviews (say how many: "dozens of reviews say it went on in one day") or the owner. Anything else is a `[CONFIRM: …]` mark, written as the question the owner has to answer ("[CONFIRM: is the metal roof warranty 50 years, and what does it cover?]").
- **Nothing the reviews contradict.** If reviewers complain about pushy sales, the ad doesn't say "no pressure". If they say it costs more, don't claim it's cheap; answer with what the money buys.
- **Search for the opposite before you use a proof.** A claim most reviews back can still be contradicted by a few. In the roofer test, most reviews praised the cleanup, but about 10 of 421 found nails left in the yard, so "the crew picks up every last nail" came out of the script.
- **Count by reading, not by keyword.** A keyword pass for "one day" found 56 reviews; read one by one, 48 said the roof went on in a day. Put the read number in the script.
- **Quotes from reviews are real and attributed.** The FTC's 2024 rule bans made-up or altered testimonials.
- **Health, money and results claims need the owner's evidence.** If they can't back it, cut it.
- **The voice:** True Nutra speaks as someone recommending it ("The one I recommend is…"). A business speaking for itself says "That's why we…". Pick one and keep it.

## The file
One table, then the open questions:

    # Board ad: <business>
    | Time | Picture | Voice | On screen |
    |---|---|---|---|
    | 0:00 | The board, pointer on row 1 | If your roof leaks every time it rains, you need a metal roof. | the spoken line |
    …
    ## [CONFIRM] before it runs
    1. …

The picture for 0:00–0:24 is `board.mp4`. For the rest, list what the owner needs to film or send (the product in hand, the job site, the team), or hand the script to the A7 video skills.
