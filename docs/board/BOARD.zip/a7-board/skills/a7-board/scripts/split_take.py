#!/usr/bin/env python3
"""Split one continuous voice take of the six lines into voice/01..06 at its pauses.

    python3 scripts/split_take.py board/<slug> [--take voice/take.mp3]

Voicing the six lines in one take keeps the delivery flowing from row to row; six separate generations
restart the same intonation every line and the repeated "you need..." sounds forced. The take is cut at its
pauses nearest where each sentence should end (predicted from the lines' word counts in lines.json, since a
comma pause can run as long as a full stop), and each line keeps a little air either side. Fails if two lines
would cut at the same pause.
Needs ffmpeg and ffprobe on the PATH.
"""
import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

NOISE = '-35dB'  # quieter than this counts as a pause
MIN_PAUSE = 0.12  # seconds
AIR_BEFORE, AIR_AFTER = 0.04, 0.12  # seconds of the pause kept on each side of a line
BREATH = 0.1  # two pauses closer than this are one pause with a breath in it


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('run', type=Path, help='the board folder, e.g. board/my-business')
    parser.add_argument('--take', default='voice/take.mp3', help='the one-take voice file in the run folder')
    args = parser.parse_args()

    for tool in ('ffmpeg', 'ffprobe'):
        if not shutil.which(tool):
            raise SystemExit(f'{tool} is not on the PATH. Install ffmpeg (brew install ffmpeg) and run again.')
    take = args.run / args.take
    if not take.exists():
        raise SystemExit(f'Missing {take}: voice all six lines in one generation and save it there.')

    length = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(take)],
                                  capture_output=True, text=True, check=True).stdout)
    log = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(take), '-af', f'silencedetect=noise={NOISE}:d={MIN_PAUSE}',
                          '-f', 'null', '-'], capture_output=True, text=True, check=True).stderr
    starts = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', log)]
    ends = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', log)]
    # Pauses inside the speech, not the silence the file starts or ends with.
    pauses: list[tuple[float, float]] = []
    for a, b in zip(starts, ends):
        if a <= 0.05 or b >= length - 0.05:
            continue
        if pauses and a - pauses[-1][1] < BREATH:
            pauses[-1] = (pauses[-1][0], b)
        else:
            pauses.append((a, b))
    board = json.loads((args.run / 'lines.json').read_text())
    words = [len(f'{line["spoken"]}, you need {board["answer_spoken"]}.'.split()) for line in board['lines']]
    rows = len(words)
    speech_start = ends[0] if starts and starts[0] <= 0.05 and ends else 0.0
    speech_end = starts[-1] if starts and ends and ends[-1] >= length - 0.05 else length
    cuts = []
    for k in range(1, rows):
        expected = speech_start + (speech_end - speech_start) * sum(words[:k]) / sum(words)
        cuts.append(min(pauses, key=lambda p: abs((p[0] + p[1]) / 2 - expected)))
    if len(set(cuts)) != rows - 1:
        raise SystemExit(f'Two lines would cut at the same pause in {take}. '
                         f'Voice it again with a clear full stop after each line.')
    bounds = [speech_start] + [x for cut in cuts for x in cut] + [speech_end]
    (args.run / 'voice').mkdir(exist_ok=True)
    for n in range(rows):
        a = max(0.0, bounds[2 * n] - AIR_BEFORE)
        b = min(length, bounds[2 * n + 1] + AIR_AFTER)
        out = args.run / 'voice' / f'{n + 1:02d}.wav'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(take), '-ss', f'{a:.3f}', '-to', f'{b:.3f}',
                        '-ar', '48000', str(out)], check=True)
        print(f'voice/{n + 1:02d}.wav  {a:6.2f}-{b:6.2f} s  ({b - a:.2f} s)')
    print('Pauses cut at: ' + ', '.join(f'{a:.2f}-{b:.2f}' for a, b in cuts))


if __name__ == '__main__':
    main()
