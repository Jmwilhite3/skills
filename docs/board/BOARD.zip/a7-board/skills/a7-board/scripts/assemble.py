#!/usr/bin/env python3
"""Cut the board section: the Wan board video, the six voiced lines and their captions.

    uv run --with pillow python3 scripts/assemble.py board/<slug> [--video board.mp4] [--lead 0.3]

Reads <run>/lines.json, <run>/voice/01..06 (.mp3 or .wav, one file per row) and the board video, and writes
<run>/board-ad.mp4: 1080x1920, 30 fps, H.264 + AAC. Each caption shows the "If..." half, then the "you need..."
half, split in proportion to their words, in white with a black outline like the original ad.

Timing: when lines.json has "arrivals" (the times in board.mp4 when the pointer reaches each row, row 1 being
when the hand comes in), each row's stretch of the clip is retimed to lead + its line + a short gap, so every
line starts just after the pointer lands on its row. Without "arrivals", line k starts at k x row_seconds + lead.

Camera (--camera, or "camera" in lines.json; punch by default): "still" keeps Wan's locked-off shot; "punch" is True Nutra's
move: wide for rows 1-2, then a cut in close on the IF YOU column at row 3 and a tilt down with the pointer to
row 6; "tilt" holds a gentle push-in the whole way and tilts down with the pointer. Both moves need "rows_y" in
lines.json: the height of row 1's centre and row 6's centre as fractions of the frame (the roofer board: 0.25, 0.84).

--video can be board.png for a dry run before the Wan clip exists: the still is held for the whole section.
Needs ffmpeg and ffprobe on the PATH, Pillow, and a bold font (macOS Arial Bold by default; --font to change).
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1080, 1920, 30
FONT = '/System/Library/Fonts/Supplemental/Arial Bold.ttf'
CAPTION_CENTER_Y = 0.70  # above the Reels caption and button zone, below the middle rows
CAPTION_SIZE = 64
CAPTION_MAX_WIDTH = 900
OUTLINE = 6
TAIL = 1.0  # seconds held after the last line when the board is a still
GAP = 0.15  # the shortest silence between one line and the next
MIN_SPEED, MAX_SPEED = 0.5, 2.0  # how far a row's stretch of the clip may be slowed or sped up to fit its line
LOUDNESS = -14  # LUFS, integrated
ZOOM = {'punch': 1.5, 'tilt': 1.2}  # how far each camera move closes in
CAMERA_LEFT = 0.02  # the crop's left edge, as a fraction of the frame: the IF YOU column stays in shot
SUPERSAMPLE = 2  # the move is cropped at twice the size so a slow tilt doesn't step a pixel at a time


def follow(points: list[tuple[float, float]]) -> str:
    """An ffmpeg expression of t that moves through (time, value) points in straight lines and holds at the ends."""
    expr = f'{points[-1][1]:.5f}'
    for (t0, v0), (t1, v1) in reversed(list(zip(points, points[1:]))):
        expr = f'if(lt(t,{t1:.3f}),{v0:.5f}+({v1 - v0:.5f})*(t-{t0:.3f})/{t1 - t0:.3f},{expr})'
    return f'if(lt(t,{points[0][0]:.3f}),{points[0][1]:.5f},{expr})'


def camera_move(zoom: float, centres: list[tuple[float, float]]) -> str:
    """Filters that close in by `zoom` and keep the row centres (time, height fraction) in the middle of the shot."""
    zw, zh, cw, ch = W * zoom * SUPERSAMPLE, H * zoom * SUPERSAMPLE, W * SUPERSAMPLE, H * SUPERSAMPLE
    y = f"clip(({follow(centres)})*{zh:.1f}-{ch / 2:.1f},0,{zh - ch:.1f})"
    return (f"scale={zw:.0f}:{zh:.0f}:flags=lanczos,crop={cw:.0f}:{ch:.0f}:{CAMERA_LEFT * zw:.1f}:'{y}',"
            f"scale={W}:{H}:flags=lanczos")


def need(tool: str) -> None:
    if not shutil.which(tool):
        raise SystemExit(f'{tool} is not on the PATH. Install ffmpeg (brew install ffmpeg) and run again.')


def duration(path: Path) -> float:
    out = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(path)],
                         capture_output=True, text=True, check=True).stdout.strip()
    return float(out)


def voice_file(run: Path, n: int) -> Path:
    for ext in ('mp3', 'wav', 'm4a'):
        path = run / 'voice' / f'{n:02d}.{ext}'
        if path.exists():
            return path
    raise SystemExit(f'Missing {run}/voice/{n:02d}.mp3 (or .wav/.m4a): one voice file per row.')


def wrap(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont) -> list[str]:
    """One line if it fits; otherwise two lines of even width, so no word sits alone on the second line."""
    words = text.split()
    if draw.textlength(text, font=font) <= CAPTION_MAX_WIDTH:
        return [text]
    splits = [(' '.join(words[:i]), ' '.join(words[i:])) for i in range(1, len(words))]
    best = min(splits, key=lambda pair: max(draw.textlength(part, font=font) for part in pair))
    if max(draw.textlength(part, font=font) for part in best) > CAPTION_MAX_WIDTH:
        raise SystemExit(f'"{text}" needs more than two caption lines. Shorten the spoken line.')
    return list(best)


def caption(text: str, font_path: str, out: Path) -> None:
    """A full-frame transparent PNG with the caption centred at CAPTION_CENTER_Y."""
    image = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(font_path, CAPTION_SIZE)
    rows = wrap(draw, text, font)
    line_height = int(CAPTION_SIZE * 1.18)
    top = int(H * CAPTION_CENTER_Y - line_height * len(rows) / 2)
    for i, row in enumerate(rows):
        x = (W - draw.textlength(row, font=font)) / 2
        draw.text((x, top + i * line_height), row, font=font, fill='white', stroke_width=OUTLINE, stroke_fill='black')
    image.save(out)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('run', type=Path, help='the board folder, e.g. board/my-business')
    parser.add_argument('--video', default='board.mp4', help='the board video in the run folder (or board.png for a dry run)')
    parser.add_argument('--lead', type=float, default=0.3, help='seconds between the pointer reaching a row and the voice')
    parser.add_argument('--font', default=FONT, help='a bold .ttf/.ttc for the captions')
    parser.add_argument('--out', default='board-ad.mp4')
    parser.add_argument('--camera', choices=('still', 'punch', 'tilt'), help='the camera move (default: lines.json "camera", else punch)')
    args = parser.parse_args()

    need('ffmpeg')
    need('ffprobe')
    if not Path(args.font).exists():
        raise SystemExit(f'Missing font {args.font}. Pass --font with a bold .ttf.')
    board = json.loads((args.run / 'lines.json').read_text())
    row_seconds = float(board['row_seconds'])
    lines = board['lines']
    video = args.run / args.video
    if not video.exists():
        raise SystemExit(f'Missing {video}. Step 7 makes it (references/board.md), or pass --video board.png for a dry run.')

    still = video.suffix.lower() in ('.png', '.jpg', '.jpeg')
    voices = [voice_file(args.run, n) for n in range(1, len(lines) + 1)]
    lengths = [duration(path) for path in voices]
    problems = []
    timings = []  # (start, length) of each line in the cut
    segments = []  # (clip start, clip end, length in the cut) per row, when the clip is retimed to the voice

    arrivals = board.get('arrivals')
    if arrivals and not still:
        # Wan never lands the pointer exactly on time. Each row's stretch of the clip, from the pointer reaching it to
        # the pointer reaching the next, is sped up or slowed down to fit its line.
        clip = duration(video)
        if len(arrivals) != len(lines):
            problems.append(f'"arrivals" has {len(arrivals)} times for {len(lines)} rows.')
        elif arrivals[0] < 0 or arrivals[-1] >= clip or any(b <= a for a, b in zip(arrivals, arrivals[1:])):
            problems.append(f'"arrivals" must rise from row 1 to row {len(lines)}, inside the {clip:.1f} s video.')
        else:
            at = 0.0
            for n, (a, b, length) in enumerate(zip(arrivals, arrivals[1:] + [clip], lengths)):
                fit = args.lead + length + GAP
                speed = (b - a) / fit
                if not MIN_SPEED <= speed <= MAX_SPEED:
                    problems.append(f'Row {n + 1}: the pointer stays {b - a:.1f} s on it and its line needs {fit:.1f} s, '
                                    f'a {speed:.2f}x change (allowed {MIN_SPEED}-{MAX_SPEED}x). Re-run Wan for this board.')
                segments.append((a, b, fit))
                timings.append((at + args.lead, length))
                at += fit
        section = sum(fit for _, _, fit in segments)
    else:
        section = len(lines) * row_seconds + TAIL if still else duration(video)
        for n, (line, length) in enumerate(zip(lines, lengths)):
            start = n * row_seconds + args.lead
            if length > row_seconds - GAP:
                problems.append(f'voice/{n + 1:02d} runs {length:.2f} s; a {row_seconds:g} s row fits {row_seconds - GAP:.2f} s. '
                                f'Shorten "{line["spoken"]}", or raise row_seconds in lines.json and make the board '
                                f'video that much longer.')
            if start + length > section:
                problems.append(f'voice/{n + 1:02d} ends at {start + length:.1f} s, after the board video ({section:.1f} s).')
            timings.append((start, length))
    camera = args.camera or board.get('camera', 'punch')
    rows_y = board.get('rows_y')
    if camera != 'still' and (not rows_y or len(rows_y) != 2):
        problems.append(f'The "{camera}" camera needs "rows_y" in lines.json: row 1\'s and row {len(lines)}\'s centre heights.')
    if camera != 'still' and CAMERA_LEFT + 1 / ZOOM[camera] > 1:
        problems.append(f'CAMERA_LEFT {CAMERA_LEFT} and zoom {ZOOM[camera]} crop past the right edge of the frame.')
    if problems:
        print('\n'.join(f'- {p}' for p in problems), file=sys.stderr)
        sys.exit(1)
    row_starts = [start - args.lead for start, _ in timings]

    work = args.run / 'captions'
    work.mkdir(exist_ok=True)
    overlays = []  # (png, start, end)
    for n, (line, (start, length)) in enumerate(zip(lines, timings), 1):
        first = line['spoken']
        second = f'you need {board["answer_spoken"]}'
        split = start + length * len(first.split()) / (len(first.split()) + len(second.split()))
        for half, text, a, b in (('a', first, start, split), ('b', second, split, start + length)):
            png = work / f'{n:02d}{half}.png'
            caption(text, args.font, png)
            overlays.append((png, a, b))

    cmd = ['ffmpeg', '-v', 'error', '-y']
    cmd += ['-loop', '1', '-t', f'{section:.3f}', '-i', str(video)] if still else ['-i', str(video)]
    for path in voices:
        cmd += ['-i', str(path)]
    for png, _, _ in overlays:
        cmd += ['-loop', '1', '-t', f'{section:.3f}', '-i', str(png)]

    frame = f'scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H},fps={FPS},setsar=1'
    if segments:
        graph = [f'[0:v]split={len(segments)}' + ''.join(f'[s{i}]' for i in range(len(segments)))]
        for i, (a, b, fit) in enumerate(segments):
            graph.append(f'[s{i}]trim=start={a:.3f}:end={b:.3f},setpts=(PTS-STARTPTS)*{fit / (b - a):.5f}[r{i}]')
        graph.append(''.join(f'[r{i}]' for i in range(len(segments))) + f'concat=n={len(segments)}:v=1:a=0,{frame}[v0]')
    else:
        graph = [f'[0:v]{frame}[v0]']
    if camera != 'still':
        step = (rows_y[1] - rows_y[0]) / (len(lines) - 1)
        centres = [(t, rows_y[0] + step * n) for n, t in enumerate(row_starts)]
        if camera == 'tilt':
            graph.append(f'[v0]{camera_move(ZOOM["tilt"], centres)}[v0cam]')
        else:
            cut = row_starts[2]  # the cut in close lands with row 3, as True Nutra's does
            close = [(t - cut, y) for t, y in centres[2:]]
            graph += [f'[v0]split[wide][near]',
                      f'[wide]trim=end={cut:.3f},setpts=PTS-STARTPTS[w0]',
                      f'[near]trim=start={cut:.3f},setpts=PTS-STARTPTS,{camera_move(ZOOM["punch"], close)}[n0]',
                      f'[w0][n0]concat=n=2:v=1:a=0[v0cam]']
    last = 'v0cam' if camera != 'still' else 'v0'
    first_png = 1 + len(voices)
    for i, (_, a, b) in enumerate(overlays):
        graph.append(f"[{last}][{first_png + i}:v]overlay=0:0:enable='between(t,{a:.3f},{b:.3f})'[v{i + 1}]")
        last = f'v{i + 1}'
    for i, (start, _) in enumerate(timings):
        ms = int(start * 1000)
        graph.append(f'[{i + 1}:a]aresample=48000,adelay={ms}|{ms}[a{i + 1}]')
    # Social feeds play at about -14 LUFS; the voice lines arrive near -22.
    graph.append(''.join(f'[a{i + 1}]' for i in range(len(voices))) + f'amix=inputs={len(voices)}:normalize=0,'
                 f'loudnorm=I={LOUDNESS}:TP=-1.5:LRA=11,aresample=48000[aout]')

    out = args.run / args.out
    cmd += ['-filter_complex', ';'.join(graph), '-map', f'[{last}]', '-map', '[aout]',
            '-t', f'{section:.3f}', '-c:v', 'libx264', '-crf', '18', '-preset', 'medium', '-pix_fmt', 'yuv420p',
            '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', str(out)]
    subprocess.run(cmd, check=True)
    print(f'Wrote {out} ({section:.1f} s, camera {camera}). Lines start at ' + ', '.join(f'{s:.1f}' for s, _ in timings) + ' s.')


if __name__ == '__main__':
    main()
