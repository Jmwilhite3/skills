#!/usr/bin/env python3
"""Check a board's six lines against the reviews they cite.

    python3 scripts/check_lines.py board/<slug> [--rows 6]

Reads <run>/lines.json and <run>/reviews.jsonl (formats in references/lines.md and references/reviews.md).
Fails, listing every problem, if a line has fewer than two receipts from different reviews, a receipt cites
an id that isn't in reviews.jsonl, a quote isn't in its review word for word, a board line runs over 7
words, a spoken line doesn't start with "If", or the answer is empty. On a pass it prints the receipts
table for buyers.md.
"""
import argparse
import json
import re
import sys
from pathlib import Path

MAX_BOARD_WORDS = 7
MIN_RECEIPTS = 2


def normal(text: str) -> str:
    """Lower case, straight quotes, single spaces: the only differences a quote may have from its review."""
    text = text.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    return re.sub(r'\s+', ' ', text).strip().lower()


def load_reviews(path: Path) -> dict[str, str]:
    if not path.exists():
        raise SystemExit(f'Missing {path}. Step 2 writes it (references/reviews.md).')
    reviews: dict[str, str] = {}
    for n, raw in enumerate(path.read_text().splitlines(), 1):
        if not raw.strip():
            continue
        record = json.loads(raw)
        if 'id' not in record or 'text' not in record:
            raise SystemExit(f'{path}:{n} needs an "id" and a "text".')
        if record['id'] in reviews:
            raise SystemExit(f'{path}:{n} repeats the id {record["id"]}. Ids must be unique.')
        reviews[record['id']] = record['text']
    return reviews


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('run', type=Path, help='the board folder, e.g. board/my-business')
    parser.add_argument('--rows', type=int, default=6, help='rows on the board (6 unless buyers.md says why not)')
    args = parser.parse_args()

    lines_path = args.run / 'lines.json'
    if not lines_path.exists():
        raise SystemExit(f'Missing {lines_path}. Step 4 writes it (references/lines.md).')
    board = json.loads(lines_path.read_text())
    reviews = load_reviews(args.run / 'reviews.jsonl')
    normal_reviews = {rid: normal(text) for rid, text in reviews.items()}

    problems: list[str] = []
    if not str(board.get('answer', '')).strip():
        problems.append('"answer" is empty: it is the YOU NEED text on every row.')
    if not str(board.get('answer_spoken', '')).strip():
        problems.append('"answer_spoken" is empty: it is what the voice says after each line.')
    lines = board.get('lines', [])
    if len(lines) != args.rows:
        problems.append(f'{len(lines)} lines, expected {args.rows}.')

    for n, line in enumerate(lines, 1):
        label = f'Line {n} ("{line.get("board", "")}")'
        words = len(str(line.get('board', '')).split())
        if words == 0:
            problems.append(f'{label}: "board" is empty.')
        elif words > MAX_BOARD_WORDS:
            problems.append(f'{label}: {words} words on the board; {MAX_BOARD_WORDS} fit in a hand-written box.')
        if not str(line.get('spoken', '')).startswith('If '):
            problems.append(f'{label}: "spoken" must start with "If ".')
        if not str(line.get('icon', '')).strip():
            problems.append(f'{label}: "icon" is empty: the board needs a sketch for every row.')
        receipts = line.get('receipts', [])
        ids = {r.get('id') for r in receipts}
        if len(ids) < MIN_RECEIPTS:
            problems.append(f'{label}: {len(ids)} different review(s) behind it; it needs {MIN_RECEIPTS}.')
        for receipt in receipts:
            rid, quote = receipt.get('id'), str(receipt.get('quote', ''))
            if rid not in reviews:
                problems.append(f'{label}: receipt id {rid} is not in reviews.jsonl.')
            elif not quote.strip():
                problems.append(f'{label}: receipt {rid} has no quote.')
            elif normal(quote) not in normal_reviews[rid]:
                problems.append(f'{label}: "{quote}" is not word for word in review {rid}.')

    if problems:
        print(f'{len(problems)} problem(s) in {lines_path}:', file=sys.stderr)
        for p in problems:
            print(f'- {p}', file=sys.stderr)
        sys.exit(1)

    print(f'Passed: {len(lines)} lines, every quote found word for word.\n')
    print('| # | Line | Reviews | Their words |')
    print('|---|---|---|---|')
    for n, line in enumerate(lines, 1):
        quotes = '; '.join(f'"{r["quote"]}" ({r["id"]})' for r in line['receipts'])
        print(f'| {n} | {line["board"]} | {len({r["id"] for r in line["receipts"]})} | {quotes} |')


if __name__ == '__main__':
    main()
