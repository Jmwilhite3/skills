---
name: a7-board
description: >
  Turn a business's own customer reviews into the "IF YOU / YOU NEED" whiteboard ad, the format True Nutra
  kept running after the same ad on a chalkboard was cut in 18 days. Reads the reviews, finds the six most
  common reasons people bought (each a different buyer, each in the buyers' own words, each backed by at
  least two reviews whose quotes a script checks), writes the full 60-second ad script, draws the hand-drawn
  board on Higgsfield, animates it with Wan 3.0, then voices and captions it into a ready 9:16 clip.
  Commands: "make a board for [business]", "read my reviews", "write the six lines", "build the board",
  "voice the board". Also use for "whiteboard ad", "if you / you need ad", "checklist ad", "BOARD".
  Never invents a review, a quote, a claim or an offer.
---

# A7 Board (your reviews → the whiteboard ad)

A checklist where every row is a different buyer and every row has the same answer:

> IF YOU — your roof leaks every time it rains → YOU NEED — a metal roof
> IF YOU — the last roofer got it wrong → YOU NEED — a metal roof
> … six rows, one hand with a pointer moving down them while a voice reads each one.

**Why it works.** True Nutra launched the same product on a chalkboard and on this board the same day (26 Sep 2026). The chalkboard explained how the problem works; it was cut 18 days later. The board just asked six questions, and four weeks later it was still running.
- **A lesson asks the viewer to learn before they care. A checklist asks one question per row: is this me?** The viewer does the work of matching themselves to the ad.
- **Six rows are six buyers in one ad.** The targeting happens inside the creative: the person with the leak and the person dreading hurricane season each find their row.
- **The same answer on every row.** By row four the viewer says it before the voice does.
- **Their words, not yours.** Lines lifted from reviews sound like the buyer's own thoughts. That's why this skill starts from reviews and not from a brainstorm.

## The run
Everything for one business goes in `board/<business-slug>/` under the current folder.

| Step | You get | Read first | Credits |
|---|---|---|---|
| 1. Intake | what they sell, where the reviews are, the real offer | this file | 0 |
| 2. Reviews | `reviews.jsonl`, every review with a stable id | `references/reviews.md` | 0 |
| 3. Buyers | `buyers.md`: every reason people bought, counted, with quotes | `references/reviews.md` | 0 |
| 4. Six lines | `lines.json`, passed by `scripts/check_lines.py` | `references/lines.md` | 0 |
| 5. Script | `script.md`, the full 60 s ad | `references/script.md` | 0 |
| 6. Board | `board.png`, text checked letter by letter | `references/board.md` | 0.25 a try |
| **Gate** | show the six lines with their receipts and the board; quote steps 7–8 and wait for "go" | | |
| 7. Animate | `board.mp4`: Wan 3.0, the pointer down the six rows | `references/board.md` | ~47 (27 s, 720p) |
| 8. Voice and cut | `voice/01–06.mp3`, then `board-ad.mp4` with captions | `references/board.md` | ~1.5 |

Credits are Higgsfield's prices in Oct 2026. Preflight every generation with `get_cost: true` and quote the real number.

## Step 1: intake
Ask in one message, with a proposed default for each so the owner can just say "yes":
1. **The business and the answer.** What goes in the YOU NEED column: the product, or the thing people book ("a free roof inspection"). One answer for all six rows.
2. **Where the reviews are.** A file, a paste, or a link (`references/reviews.md` says what each source needs).
3. **What's true for the script:** the offer, the guarantee, the proof (years, numbers, warranty), the CTA and where it points. Anything they don't give stays a `[CONFIRM: …]` mark in the script; it never gets made up.
4. **The voice:** a Higgsfield preset (default: a warm female voice, as in the original) or their own recording, one file per line.

Keep working on steps 2–5 while they answer.

## Steps 2–4: from reviews to six lines
Follow `references/reviews.md` and `references/lines.md`. The short version:
- **Read for the before, not the praise.** Most reviews praise the crew. The lines come from what was going on before they bought: said outright ("we developed a leak during a lot of rain storms") or as a contrast ("no more leaks", "won't have to climb the ladder anymore").
- **One buyer per line,** each backed by at least two reviews, each worded the way they said it, each something the viewer can check about themselves in a second.
- **Run the check:**
  `python3 scripts/check_lines.py board/<slug>`
  It fails if a quote isn't word for word in the review it cites, a line has fewer than two reviews, or a board line is too long to hand-write in its box. Fix and re-run until it passes, then paste its receipts table into `buyers.md`.

## Step 5: the script
Follow `references/script.md`: the board, the turn, the answer, how it works, what changes, the offer. Every claim comes from the reviews (with a count) or from the owner. Nothing the reviews contradict goes in.

## Steps 6–8: build it
Follow `references/board.md`.
1. Draw `board.png` with `gpt_image_2_5`, then read every word on it at full size. One wrong letter means redraw.
2. **The gate.** Show the owner the six lines with their receipts, the board and the script's `[CONFIRM]` marks. Quote the Wan and voice credits. Wait for "go".
3. Animate with `wan3_0` from the board. Check the words, then measure when the pointer reaches each row and write the times into `lines.json` as `arrivals` (Wan never keeps time). Voice the six lines, then cut:
   `uv run --with pillow python3 scripts/assemble.py board/<slug>`

## Hand-over
Show, in this order: the clip, the board, the six lines with their receipts, then the script with every `[CONFIRM]` listed as a question. The board covers the first 25 seconds or so of the script. The rest (turn, answer, offer) plays over the owner's own footage or product shots, or goes to the A7 video skills.

## The rules
1. **Nothing invented.** No line without two reviews behind it, no quote that isn't word for word, no claim or offer the owner hasn't confirmed.
2. **Their words.** Trim the reviewer's phrase; don't rewrite it into marketing.
3. **Meta's personal-attributes rule.** No line may assert a health condition, money trouble or any other personal attribute ("Do you have diabetes?" is Meta's own example of a ban). Name the sign instead: "your socks leave marks around your ankles", not "you have poor circulation".
4. **Check before you spend.** Text on the board is read letter by letter before Wan runs, and credits are quoted before every paid step.
